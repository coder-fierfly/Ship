package com.company;

import javax.swing.*;
import java.awt.*;

public class Main {

    public static void main(String[] args) {
        new Main();
    }

    public Main() {
        createUI();
    }

    public void createUI() {
        JFrame frame = new JFrame();
        frame.setSize(700, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setBackground(Color.black);
        frame.setLayout(null);

        JPanel shipPanel = new JPanel();
        shipPanel.setBounds(100,170,200,200);
        shipPanel.setBackground(Color.black);
        frame.add(shipPanel);

        ImageIcon ship = new ImageIcon(getClass().getClassLoader().getResource("whymom.png"));

        JButton button = new JButton();
        button.setBackground(Color.cyan);
        button.setFocusPainted(false);
        button.setBorder(null);
        button.setIcon(ship);
        shipPanel.add(button);

        frame.setVisible(true);
    }
}